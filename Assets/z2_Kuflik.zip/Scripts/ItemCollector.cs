using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemCollector : MonoBehaviour {
   private int _itemsCollected = 0;

   [SerializeField] private Text itemsCollectedUItext;
   private void OnTriggerEnter2D(Collider2D col)
   {
      if (col.gameObject.CompareTag("Orange"))
      {
         Destroy(col.gameObject);
         _itemsCollected++;
         itemsCollectedUItext.text = "Oranges: " + _itemsCollected + "/4";
      }
   }
}
